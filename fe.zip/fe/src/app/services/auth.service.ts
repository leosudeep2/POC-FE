import { AuthResponse } from "./../beans/response/auth.response.bean";
import { OBTAIN_OAUTH_TOKEN_URL } from "./../constants/api-urls.constant";
import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from "@angular/common/http";
import { catchError } from "rxjs/operators";
import { throwError } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class AuthService {
  constructor(private httpClient: HttpClient) {}

  // checkEmailAvailability(emailId: string) {
  //   console.log("inside check email service" + emailId);
  //   // let params = new HttpParams().set('email', emailId);
  //   return this.httpClient.post<any>(CHECK_EMAIL_URL, emailId);
  // }

  // checkMobileAvailability(mobile: string) {
  //   return this.httpClient.post<any>(CHECK_MOBILE_URL, mobile);
  // }

  // verifyOTP(payload: SignupBean) {
  //   let httpHeaders = new HttpHeaders();
  //   httpHeaders.set("Content-type", "application/json");
  //   return this.httpClient.post(VERIFY_OTP_URL, payload, {
  //     headers: httpHeaders
  //   });
  // }

  // generateOTP(mobileNumber: number) {
  //   return this.httpClient.post(GENERATE_OTP_URL, mobileNumber);
  // }

  login(username: string, password: string) {
    let params = new URLSearchParams();
    params.append("grant_type", "password");
    params.append("username", username);
    params.append("password", password);
    params.append("scopes", "read write");

    let headers = new HttpHeaders({
      "Content-type": "application/x-www-form-urlencoded; charset=utf-8",
      Authorization: "Basic " + btoa("myapp:1234")
    });
    return this.httpClient
      .post<AuthResponse>(OBTAIN_OAUTH_TOKEN_URL, params.toString(), {
        headers: headers
      })
      .pipe(catchError(this.errorHandler));
  }

  errorHandler(errorResponse: HttpErrorResponse) {
    console.log(errorResponse);
    if (errorResponse.status == 400) {
      return throwError({
        alert: "alert!",
        message: errorResponse.error.error_description
      });
    }
    return throwError({ alert: "alert!", message: errorResponse.message });
  }
}
