import { AuthErrorResponse } from "./../../beans/response/auth-error.response.bean";
import { AuthService } from "./../../services/auth.service";
import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { MatSnackBar } from "@angular/material";

@Component({
  selector: "app-landing",
  templateUrl: "./landing.component.html",
  styleUrls: ["./landing.component.scss"]
})
export class LandingComponent implements OnInit {
  hide: boolean = true; //hide password data by defualt
  loginForm: FormGroup;
  errorResponse: AuthErrorResponse;
  loream: string;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private snackBar: MatSnackBar,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loginForm = this.fb.group({
      email: ["", [Validators.required, Validators.email]],
      password: ["", Validators.required]
    });
    this.loream =
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).";
  }

  onLogin() {
    if (this.loginForm.valid) {
      this.errorResponse = null;
      this.authService.login(this.email.value, this.password.value).subscribe(
        response => {
          this.router.navigate(["/home"]);
        },
        error => {
          this.errorResponse = error;
          this.loginForm.setErrors;
        }
      );
    }
  }

  getEmailErrorMessage() {
    return this.email.hasError("required")
      ? "You must enter email"
      : this.email.hasError("email")
      ? "Not a valid email"
      : "";
  }

  getPasswordErrorMessage() {
    return this.password.hasError("required")
      ? "You must enter your password"
      : "";
  }

  get email() {
    return this.loginForm.get("email");
  }
  get password() {
    return this.loginForm.get("password");
  }
}
