import {
  CookiesStorageService,
  Keys
} from "./../../commons/cookies-storage/cookies-storage.service";
import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit {
  isAuthenticated: boolean = false;

  constructor(private cookieStorageService: CookiesStorageService) {}

  ngOnInit() {
    let data = this.cookieStorageService.getCookieItem(Keys.isAuthenticated);
    if (data != undefined && null != data && Boolean(data)) {
      this.isAuthenticated = Boolean(data);
    }
  }
}
