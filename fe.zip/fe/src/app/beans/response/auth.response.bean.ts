export interface AuthResponse {
  access_token: string;
  expires_in: number;
  id: number;
  jti: string;
  refresh_token: string;
  roles: string;
  scope: string;
  token_type: string;
  username: string;
  firstname: string;
}
