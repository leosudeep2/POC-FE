export interface AuthErrorResponse {
  alert: string;
  message: string;
}
