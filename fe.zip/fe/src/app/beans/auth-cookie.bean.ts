export interface AuthCookieBean {
  isAuthenticated: boolean;
  refreshToken: string;
  accessToken: string;
  fisrtName: string;
  username: string;
}
