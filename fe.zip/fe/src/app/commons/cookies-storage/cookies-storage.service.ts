import { AuthCookieBean } from "./../../beans/auth-cookie.bean";
import { AuthResponse } from "../../beans/response/auth.response.bean";
import { Injectable } from "@angular/core";
import { Cookie } from "ng2-cookies";

const APP_PREFIX = "HS-";

@Injectable({
  providedIn: "root"
})
export class CookiesStorageService {
  constructor() {}
  setJWTCookieItems(value: AuthResponse) {
    const now = new Date();
    const expiryDate = new Date(now.getTime() + value.expires_in * 60);
    Cookie.set(
      `${APP_PREFIX}` + Keys.access_token,
      value.access_token,
      expiryDate
    );
    Cookie.set(`${APP_PREFIX}` + Keys.refresh_token, value.refresh_token);
    Cookie.set(`${APP_PREFIX}` + Keys.username, value.username);
    Cookie.set(`${APP_PREFIX}` + Keys.firstname, value.firstname);
    Cookie.set(`${APP_PREFIX}` + Keys.isAuthenticated, "true");
  }

  setCookieItem(key: string, value: any) {
    Cookie.set(`${APP_PREFIX}${key}`, value);
  }

  getCookieItem(key: Keys) {
    return Cookie.get(`${APP_PREFIX}${key}`);
  }

  getJWTAccessTokenCookie() {
    return Cookie.get("access_token");
  }

  removeCookieItem(key: string) {
    Cookie.delete(`${APP_PREFIX}${key}`);
  }

  removeJWTCookiesItem() {
    Cookie.delete(`${APP_PREFIX}` + Keys.access_token);
    Cookie.delete(`${APP_PREFIX}` + Keys.refresh_token);
    Cookie.delete(`${APP_PREFIX}` + Keys.username);
    Cookie.delete(`${APP_PREFIX}` + Keys.firstname);
    Cookie.delete(`${APP_PREFIX}` + Keys.isAuthenticated);
    Cookie.delete(`${APP_PREFIX}` + Keys.isAuthenticated);
    Cookie.deleteAll("localhost");
  }

  getAuthCookieItems(): AuthCookieBean {
    let authCookieBean: AuthCookieBean = null;
    if (
      Cookie.check(`${APP_PREFIX}` + Keys.access_token) &&
      Cookie.check(`${APP_PREFIX}` + Keys.username) &&
      Cookie.check(`${APP_PREFIX}` + Keys.firstname) &&
      Cookie.check(`${APP_PREFIX}` + Keys.refresh_token)
    ) {
      authCookieBean = {
        isAuthenticated: Boolean(
          Cookie.get(`${APP_PREFIX}` + Keys.isAuthenticated)
        ),
        refreshToken: Cookie.get(`${APP_PREFIX}` + Keys.refresh_token),
        accessToken: Cookie.get(`${APP_PREFIX}` + Keys.access_token),
        fisrtName: Cookie.get(`${APP_PREFIX}` + Keys.firstname),
        username: Cookie.get(`${APP_PREFIX}` + Keys.username)
      };
    }

    return authCookieBean;
  }
}

export enum Keys {
  access_token,
  username,
  refresh_token,
  isAuthenticated,
  firstname
}
