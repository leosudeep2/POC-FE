import {
  CookiesStorageService,
  Keys
} from "./../cookies-storage/cookies-storage.service";
import { Injectable } from "@angular/core";
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
  Route
} from "@angular/router";

@Injectable({
  providedIn: "root"
})
export class AuthGuard implements CanActivate {
  isAuthenticated = false;

  constructor(
    private router: Router,
    private cookieStorageService: CookiesStorageService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let data = this.cookieStorageService.getCookieItem(Keys.isAuthenticated);
    if (undefined !== data && null != data && Boolean(data)) {
      console.log("in Auth guard will return true");
      this.isAuthenticated = true;
      return true;
    } else {
      this.router.navigate(["/login"]);
      return false;
    }
  }

  canLoad(rout: Route) {
    // if (this.store.select(fromRoot.getIsAuthenticated)) {
    //     return true;
    // } else {
    //     this.router.navigate(['/index']);
    // }
    return this.isAuthenticated;
  }
}
