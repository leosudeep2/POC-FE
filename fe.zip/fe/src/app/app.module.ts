import { PhoneNumFormaterDirective } from "./validators/phone-num-formater.directive";
import { MaterialModule } from "./commons/material/material.module";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { AllowOnlyNumbersDirective } from "./validators/allow-only-numbers.directive";
import { AllowOnlyOneWordDirective } from "./validators/allow-only-one-word.directive";
import { AllowOnlyStringDirective } from "./validators/allow-only-string.directive";
import { RemoveSpaceDirective } from "./validators/remove-space.directive";
import { LandingComponent } from "./components/landing/landing.component";
import { NavBarComponent } from "./components/nav-bar/nav-bar.component";
import { LayoutModule } from "@angular/cdk/layout";
import {
  MatToolbarModule,
  MatButtonModule,
  MatSidenavModule,
  MatIconModule,
  MatListModule
} from "@angular/material";
import { LoginComponent } from "./components/forms/login/login.component";
import { HeaderComponent } from "./components/header/header.component";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    AllowOnlyNumbersDirective,
    AllowOnlyOneWordDirective,
    AllowOnlyStringDirective,
    RemoveSpaceDirective,
    PhoneNumFormaterDirective,
    LandingComponent,
    NavBarComponent,
    LoginComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
