export const BASE_URL = "http://localhost:9001";
export const CHECK_EMAIL_URL = BASE_URL + "/api/auth/checkEmail";
export const CHECK_MOBILE_URL = BASE_URL + "/api/auth/checkMobile";
export const VERIFY_OTP_URL = BASE_URL + "/api/auth/otpVerifyAndSignup";
export const GENERATE_OTP_URL = BASE_URL + "/api/auth/generateOtp";
export const OBTAIN_OAUTH_TOKEN_URL = BASE_URL + "/oauth/token";
export const ADD_PROPERTY_URL = BASE_URL + "/api/v1/property/addProperty";
export const GET_ALL_PROPERTY_OF_USER_URL =
  BASE_URL + "/api/v1/property/retrieveAll";
export const DELETE_PROPERTY_BY_PROP_ID =
  BASE_URL + "/api/v1/property/removeProperty";
export const UPDATE_PROPERTY_BY_PROP_ID =
  BASE_URL + "/api/v1/property/updateProperty";
