import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
  selector: "[appRemoveSpace]"
})
export class RemoveSpaceDirective {
  constructor(private el: ElementRef) {}

  @HostListener("keypress") onKeyPress() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(" ", "");
    this.el.nativeElement.value = value;
  }

  @HostListener("keyup") onKeyUp() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(" ", "");
    this.el.nativeElement.value = value;
  }
}
