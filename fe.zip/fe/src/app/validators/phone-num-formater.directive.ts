import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
  selector: "[appPhoneNumFormat]"
})
export class PhoneNumFormaterDirective {
  constructor(private el: ElementRef) {}

  @HostListener("keyup") onKeyUp() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(/\D+/g, "");
    value = value.replace(/(\d{3})\.?(\d{3})\.?(\d{1})/, "$1-$2-$3");
    if (value.length > 12) {
      value = value.substring(0, 12);
    }
    this.el.nativeElement.value = value;
  }
}
