import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
  selector: "[appAllowOnlyString]"
})
export class AllowOnlyStringDirective {
  constructor(private el: ElementRef) {}

  @HostListener("keyup") onKeyUp() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(/[^a-zA-Z &\s]/, "");
    this.el.nativeElement.value = value;
  }

  @HostListener("keypress") onKeyPress() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(/[^a-zA-Z &\s]/, "");
    this.el.nativeElement.value = value;
  }

  @HostListener("down") onBlur() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(/[^a-zA-Z &\s]/, "");
    this.el.nativeElement.value = value;
  }
}
