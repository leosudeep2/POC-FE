import { Directive, HostListener, ElementRef } from "@angular/core";

@Directive({
  selector: "[appAllowOnlyOneWord]"
})
export class AllowOnlyOneWordDirective {
  constructor(private el: ElementRef) {}

  @HostListener("keyup") onKeyUp() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(/[^a-zA-Z]/, "");
    this.el.nativeElement.value = value;
  }

  @HostListener("keypress") onKeyPress() {
    let value: string = this.el.nativeElement.value;
    value = value.replace(/[^a-zA-Z]/, "");
    this.el.nativeElement.value = value;
  }
}
